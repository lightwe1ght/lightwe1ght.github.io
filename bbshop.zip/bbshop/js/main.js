function install(button){
    button.textContent = "Downloading app...";
     setTimeout(()=>{
        button.textContent = "App installed.";
     },2000);
}